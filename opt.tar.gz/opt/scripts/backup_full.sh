#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: $0 ORIGEN DESTINO"
	echo "ORIGEN: directorio a realizar backup"
	echo "DESTINO: donde guardar el backup (/backup_dir en caso de estar vacio)"
	echo "Genera DESTINO/(nombre)_bkp_(YYYYMMDD).tar.gz"
	exit 0
fi

BACKUP=$1
DEST=$2

if [ -z "$DEST" ]; then
	DEST=/backup_dir
fi

if [ ! -d "$BACKUP" ]; then
	echo "Error. El origen no existe."
	exit 1
fi

if ! mountpoint -q "$DEST"; then
	echo "Error. El destino no es un filesystem montado."
	exit 2
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$BACKUP")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

if tar czf "$DEST/$ARCHIVO" "$BACKUP"; then
	echo "Archivo generado: $ARCHIVO"
	echo "En el destino: $DEST"
else
	echo "Error. Fallo al generar el backup."
	exit 3
fi
