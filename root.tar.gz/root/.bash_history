history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
exit
clear
cat /etc
cd /etc
ls l /
ls /etc
cd ..
clear
hostname
vim /etc/hosts
clear
hostname -f
hostname
c
clear
cat /etc/apt/sources.list
clear
cp etc/apt/sources.list etc/apt/sources.list.bak
vim etc/apt/sources.list
clear
apt update
apt update
apt upgrade
clear
cat etc/debian_version
apt autoremove
clear
apt install openssh-server
cd ..
cd /root
clear
tar xzf Material_Adicional_TPVMA.tar.gz
ls 
tar xzf Material_Adicional_TPVMCA.tar.gz
ls root
ls
ls Material_Adicional_TPVMCA
mkdir -p /root/.ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys
~vim /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
clear
vim /etc/ssh/sshd_config
clear
systemctl restart ssh
systemctl status ssh
clear
head -5 /etc/ssh/sshd_config
vim /etc/ssh/sshd_config
clear
sshd -t
systemctl restart ssh
systemctl status ssh
grep PermitRootLogin /etc/ssh/sshd_config
clear
ssh -i /root/Material_Adicional_TPVMCA/clave_privada.txt
ssh -i /root/Material_Adicional_TPVMCA/clave_privada.txt root@localhost
journalctl -u ssh -n 20
ssh -v -i /root/Material_Adicional_TPVMCA/clave_privada.txt root@127.0.0.1
clear
reboot
clear
uname -r
cat /etc/debian_version
clear
dpkg -l | grep apache2
clear
apt install apache2
clear
system status apache2
systemctl status apache2
clear
apt install php libapache2-mod-php php-mysql
clear
php -v
clear
systemctl restar apache2
systemctl restart apache2
clear
ipa
ip a
ps aux | grep apache2
apt install mariadb-server
clear
systemctl status mariadb
clear
head -20 /root/Material_Adicional_TPVMCA/db.sql
clear
grep -i -E "mysqli|localhost|dbname|user|pass" /root/Material_Adicional_TPVMCA/index.php
grep -i -E "create user|grant" /root/Material_Adicional_TPVMCA/db.sql
clear
mysql < /root/Material_Adicional_TPVMCA/db.sql
mysql -e "SHOW DATABASES;"
mysql -e "SHOW TABLES;" ingenieria
mysql -e "SELECT user, host from mysql.user;"
clear
ip a
ip route
cat etc/network/interfaces
cat /etc/network/interfaces
~ping -c 3 192.168.0.40
ping -c 3 192.168.0.40
cp /etc/network/interfaces /etc/network/interfaces.bak
vim /etc/network/interfaces
clear
systemctl restar networking
systemctl restart networking
clear
ip a
reboot
exit
clear
ip a
vim etc/network/interfaces
clear
vim /etc/network/interfaces
systemctl restart networking
clear
ip a
ping .c 3 192.168.0.1
ping -c 192.168.0.1
ping -c 3 192.168.0.1
ping -c 3 8.8.8.8
ping -c 3 debian.org
clear
shutdown -h now
lsblk
cat /etc/fstab
column -t etc/fstab
cat clumn -t /etc/fstab
clear
column -t /etc/fstab
blkid /dev/sdb1
cp /etc/fstab /etc/fstab.bak
blkid -s UUID -o value /dev/sdb1 >> /etc/fstab.
vim /etc/fstab
clear
blkid -s UUID -o value /dev/sdb1 >> /etc/fstab
clear
vim /etc/fstab
clear
umount /home
mount -a
vim /etc/fstab
clear
umount /home
mount -a
systemctl dameon-reload
systemctl daemon-reload
clear
umount /home
mount a 
mount a
mount -a
lsblk
clear
fdisk /dev/sdc
lsblk
clear
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
clear
blkid /dev/sdc1 /dev/sdc2
mkdir /www_dir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
clear
cp /etc/fstab /etc/fstab.bak
blkid -s UUID -o value /dev/sdc1 >> /etc/fstab
blkid -s UUID -o value /dev/sdc2 >> /etc/fstab
clar
clear
vim /etc/fstab
clear
umount /www_dir /backup_dir
mount -a
systemctl daemon-reload
mount -a
df-h
df -h
clear
cat /proc/partitions > /opt/particion
cat /opt/particion 
clear
cp /root/Material_Adicional_TPVMCA/index.php  /root/Material_Adicional_TPVMCA/logo.png /ww_dir/
cp /root/Material_Adicional_TPVMCA/index.php  /root/Material_Adicional_TPVMCA/logo.png/ww_dir/
cp /root/Material_Adicional_TPVMCA/index.php  /root/Material_Adicional_TPVMCA/logo.png/www_dir/
cp /root/Material_Adicional_TPVMCA/index.php  /root/Material_Adicional_TPVMCA/logo.png /www_dir/
clear
ls -l /www_dir
chmod 755 /www_dir
chmod 644 /www_dir/index.php  /www_dir/logo.png 
vim /etc/apache2/sites-available/000-default.conf
clear
vim /etc/apache2/apache2.conf 
clear
apache2ctl configtest
systemctl restart apache2
clear
turnoff
shutdown
shutdown now
clear
clear
mkdir -p /opt/scripts
vim /opt/scripts/backup_full.sh
chmod 755 /opt/scripts/backup_full.sh
clear
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir ; echo $?
unmount /backup_dir
umount/backup_dir
umount /backup_dir
/opt/scripts/backup_full.sh /var/log /backup_dir ; echo $?
mount -a
ls -l /backup_dir
clear
vim /etc/crontab
clear
systemctl status cron
clear
vim /etc/crontab
clear
date
vim /etc/crontab
clear
ls -l /backup_dir 
hournalctl -u cron -n 10
journalctl -u cron -n 10
vim /etc/crontab
clear
rm /backup_dir/etc_bkp_20261114.tar.gz 
clear
reboot
clear
cat /etc/debian_version
uname -r
hostname
grep 127.0.1.1 /etc/hosts
ip a show enp0s3
ping -c 2 8.8.8.8
ping -c 2 debian.org
systemctl is-active ssh
grep ^PermitRootLogin /etc/ssh/sshd_config
systemctl is-active apache2
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
php -v
systemctl is-active mariadb
mysql -e "SHOWTABLES;" ingenieria
mysql -e "SHOW TABLES;" ingenieria
lsbk
lsblk
grep -v "^#" /etc/fstab | column -t
cat /opt/particion
ls -l /www_dir
ls -l /opt/scripts/backup_full.sh 
grep backup_full /etc/crontab
clear
grep backup_full /etc/crontab
